#!/usr/bin/env bash
set -e

PROJECT_DIR="${1:-ArabiKey}"
mkdir -p "$PROJECT_DIR"
cd "$PROJECT_DIR"

mkdir -p \
  .github/workflows \
  gradle/wrapper \
  app/src/main/java/com/arabikey/keyboard \
  app/src/main/res/xml \
  app/src/main/res/values \
  app/src/test/java/com/arabikey/keyboard

cat <<'__ARABIKEY_EOF__' > build.gradle.kts
plugins {
    id("com.android.application") version "8.5.2" apply false
    id("org.jetbrains.kotlin.android") version "1.9.24" apply false
}
__ARABIKEY_EOF__

cat <<'__ARABIKEY_EOF__' > settings.gradle.kts
pluginManagement {
    repositories {
        google()
        mavenCentral()
        gradlePluginPortal()
    }
}
dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
    repositories {
        google()
        mavenCentral()
    }
}
rootProject.name = "ArabiKey"
include(":app")
__ARABIKEY_EOF__

cat <<'__ARABIKEY_EOF__' > gradle.properties
org.gradle.jvmargs=-Xmx2048m -Dfile.encoding=UTF-8
android.useAndroidX=true
android.nonTransitiveRClass=true
kotlin.code.style=official
__ARABIKEY_EOF__

cat <<'__ARABIKEY_EOF__' > gradle/wrapper/gradle-wrapper.properties
distributionBase=GRADLE_USER_HOME
distributionPath=wrapper/dists
distributionUrl=https\://services.gradle.org/distributions/gradle-8.7-bin.zip
networkTimeout=10000
validateDistributionUrl=true
zipStoreBase=GRADLE_USER_HOME
zipStorePath=wrapper/dists
__ARABIKEY_EOF__

cat <<'__ARABIKEY_EOF__' > gradlew
#!/bin/sh
app_path=$0
while
    APP_HOME=${app_path%"${app_path##*/}"}
    [ -h "$app_path" ]
do
    ls=$( ls -ld "$app_path" )
    link=${ls#*' -> '}
    case $link in
      /*)   app_path=$link ;;
      *)    app_path=$APP_HOME$link ;;
    esac
done
APP_BASE_NAME=${0##*/}
APP_HOME=$( cd "${APP_HOME:-./}" > /dev/null && pwd -P ) || exit
MAX_FD=maximum
warn () { echo "$*"; } >&2
die () { echo; echo "$*"; echo; exit 1; } >&2
cygwin=false; msys=false; darwin=false; nonstop=false
case "$( uname )" in
  CYGWIN* )         cygwin=true  ;;
  Darwin* )         darwin=true  ;;
  MSYS* | MINGW* )  msys=true    ;;
  NONSTOP* )        nonstop=true ;;
esac
CLASSPATH=$APP_HOME/gradle/wrapper/gradle-wrapper.jar
if [ -n "$JAVA_HOME" ] ; then
    if [ -x "$JAVA_HOME/jre/sh/java" ] ; then
        JAVACMD=$JAVA_HOME/jre/sh/java
    else
        JAVACMD=$JAVA_HOME/bin/java
    fi
    if [ ! -x "$JAVACMD" ] ; then
        die "ERROR: JAVA_HOME is set to an invalid directory: $JAVA_HOME"
    fi
else
    JAVACMD=java
    command -v java >/dev/null 2>&1 || die "ERROR: JAVA_HOME is not set and java was not found."
fi
if "$cygwin" || "$msys" ; then
    APP_HOME=$( cygpath --path --mixed "$APP_HOME" )
    CLASSPATH=$( cygpath --path --mixed "$CLASSPATH" )
    JAVACMD=$( cygpath --unix "$JAVACMD" )
fi
DEFAULT_JVM_OPTS='-Dfile.encoding=UTF-8 "-Xmx64m" "-Xms64m"'
set -- "-Dorg.gradle.appname=$APP_BASE_NAME" -classpath "$CLASSPATH" org.gradle.wrapper.GradleWrapperMain "$@"
eval "set -- $(printf '%s\n' "$DEFAULT_JVM_OPTS $JAVA_OPTS $GRADLE_OPTS" | xargs -n1 | sed ' s~[^-[:alnum:]+,./:=@_]~\\&~g; ' | tr '\n' ' ')" '"$@"'
exec "$JAVACMD" "$@"
__ARABIKEY_EOF__
chmod +x gradlew

cat <<'__ARABIKEY_EOF__' > .github/workflows/build.yml
name: Build APK

on:
  push:
  workflow_dispatch:

jobs:
  build:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4

      - name: Setup JDK 17
        uses: actions/setup-java@v4
        with:
          distribution: 'temurin'
          java-version: '17'

      - name: Setup Gradle
        uses: gradle/actions/setup-gradle@v6
        with:
          gradle-version: '8.7'

      - name: Run Unit Tests and Build Debug APK
        run: |
          if [ -f gradle/wrapper/gradle-wrapper.jar ]; then
            chmod +x gradlew
            ./gradlew testDebugUnitTest assembleDebug
          else
            gradle testDebugUnitTest assembleDebug
          fi

      - name: Upload APK
        uses: actions/upload-artifact@v4
        with:
          name: ArabiKey-APK
          path: app/build/outputs/apk/debug/app-debug.apk
__ARABIKEY_EOF__

cat <<'__ARABIKEY_EOF__' > app/build.gradle.kts
plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.arabikey.keyboard"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.arabikey.keyboard"
        minSdk = 24
        targetSdk = 34
        versionCode = 2
        versionName = "2.0"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    testImplementation("junit:junit:4.13.2")
}
__ARABIKEY_EOF__

cat <<'__ARABIKEY_EOF__' > app/src/main/AndroidManifest.xml
<?xml version="1.0" encoding="utf-8"?>
<manifest xmlns:android="http://schemas.android.com/apk/res/android">

    <application
        android:allowBackup="true"
        android:label="@string/app_name"
        android:supportsRtl="true"
        android:theme="@android:style/Theme.DeviceDefault.Light.NoActionBar">

        <activity
            android:name=".SettingsActivity"
            android:exported="true"
            android:windowSoftInputMode="adjustResize">
            <intent-filter>
                <action android:name="android.intent.action.MAIN" />
                <category android:name="android.intent.category.LAUNCHER" />
            </intent-filter>
        </activity>

        <activity
            android:name=".StickerPickerActivity"
            android:exported="false"
            android:theme="@android:style/Theme.Translucent.NoTitleBar" />

        <service
            android:name=".ArabiKeyService"
            android:exported="true"
            android:label="@string/app_name"
            android:permission="android.permission.BIND_INPUT_METHOD">
            <intent-filter>
                <action android:name="android.view.InputMethod" />
            </intent-filter>
            <meta-data
                android:name="android.view.im"
                android:resource="@xml/method" />
        </service>

        <provider
            android:name="androidx.core.content.FileProvider"
            android:authorities="${applicationId}.fileprovider"
            android:exported="false"
            android:grantUriPermissions="true">
            <meta-data
                android:name="android.support.FILE_PROVIDER_PATHS"
                android:resource="@xml/file_paths" />
        </provider>

    </application>
</manifest>
__ARABIKEY_EOF__

cat <<'__ARABIKEY_EOF__' > app/src/main/res/xml/method.xml
<?xml version="1.0" encoding="utf-8"?>
<input-method xmlns:android="http://schemas.android.com/apk/res/android"
    android:settingsActivity="com.arabikey.keyboard.SettingsActivity" />
__ARABIKEY_EOF__

cat <<'__ARABIKEY_EOF__' > app/src/main/res/xml/file_paths.xml
<?xml version="1.0" encoding="utf-8"?>
<paths>
    <files-path name="stickers" path="stickers/" />
    <files-path name="backups" path="backups/" />
    <cache-path name="share_cache" path="." />
</paths>
__ARABIKEY_EOF__

cat <<'__ARABIKEY_EOF__' > app/src/main/res/values/strings.xml
<?xml version="1.0" encoding="utf-8"?>
<resources>
    <string name="app_name">كيبورد ذكي</string>
</resources>
__ARABIKEY_EOF__

cat <<'__ARABIKEY_EOF__' > app/src/main/java/com/arabikey/keyboard/KbTheme.kt
package com.arabikey.keyboard

import android.graphics.Color

data class KbTheme(
    val name: String,
    val bg: Int,
    val bar: Int,
    val key: Int,
    val keyPressed: Int,
    val action: Int,
    val actionPressed: Int,
    val text: Int,
    val muted: Int,
    val accent: Int,
    val onAccent: Int,
    val divider: Int,
    val isLight: Boolean,
) {
    companion object {
        val SNOW = KbTheme(
            name = "snow",
            bg = Color.parseColor("#EEF4FB"),
            bar = Color.parseColor("#FFFFFF"),
            key = Color.parseColor("#FFFFFF"),
            keyPressed = Color.parseColor("#D6E4F2"),
            action = Color.parseColor("#DDE8F4"),
            actionPressed = Color.parseColor("#C2D5E8"),
            text = Color.parseColor("#0F172A"),
            muted = Color.parseColor("#5B6B80"),
            accent = Color.parseColor("#0284C7"),
            onAccent = Color.parseColor("#FFFFFF"),
            divider = Color.parseColor("#240F172A"),
            isLight = true,
        )

        val BLACK = KbTheme(
            name = "black",
            bg = Color.parseColor("#000000"),
            bar = Color.parseColor("#0C0C0C"),
            key = Color.parseColor("#1D1D1D"),
            keyPressed = Color.parseColor("#353535"),
            action = Color.parseColor("#2A2A2A"),
            actionPressed = Color.parseColor("#424242"),
            text = Color.parseColor("#FFFFFF"),
            muted = Color.parseColor("#A3A3A3"),
            accent = Color.parseColor("#7C3AED"),
            onAccent = Color.parseColor("#FFFFFF"),
            divider = Color.parseColor("#28FFFFFF"),
            isLight = false,
        )

        val MIDNIGHT = KbTheme(
            name = "midnight",
            bg = Color.parseColor("#0B1324"),
            bar = Color.parseColor("#111C33"),
            key = Color.parseColor("#1B2A4A"),
            keyPressed = Color.parseColor("#2B4170"),
            action = Color.parseColor("#16233E"),
            actionPressed = Color.parseColor("#243963"),
            text = Color.parseColor("#F1F5F9"),
            muted = Color.parseColor("#94A3B8"),
            accent = Color.parseColor("#10B981"),
            onAccent = Color.parseColor("#FFFFFF"),
            divider = Color.parseColor("#28FFFFFF"),
            isLight = false,
        )

        fun byName(name: String?): KbTheme = when (name) {
            "black" -> BLACK
            "midnight" -> MIDNIGHT
            else -> SNOW
        }

        fun nextName(current: String?): String = when (current) {
            "snow" -> "black"
            "black" -> "midnight"
            else -> "snow"
        }
    }
}
__ARABIKEY_EOF__

cat <<'__ARABIKEY_EOF__' > app/src/main/java/com/arabikey/keyboard/Prefs.kt
package com.arabikey.keyboard

import android.content.Context
import org.json.JSONArray

class Prefs(context: Context) {
    private val sp = context.applicationContext.getSharedPreferences("arabikey", Context.MODE_PRIVATE)

    var theme: String
        get() = sp.getString("theme", "snow") ?: "snow"
        set(v) = sp.edit().putString("theme", v).apply()

    /** 0 صغير، 1 متوسط، 2 كبير (افتراضي)، 3 ضخم */
    var keyHeight: Int
        get() = sp.getInt("keyHeight", 2)
        set(v) = sp.edit().putInt("keyHeight", v).apply()

    /** 0 عادي، 1 كبير (افتراضي)، 2 ضخم */
    var fontSize: Int
        get() = sp.getInt("fontSize", 1)
        set(v) = sp.edit().putInt("fontSize", v).apply()

    /** 0 مدمج كبير (١٠ مفاتيح/صف)، 1 أزرار ضخمة (٨ مفاتيح/صف)، 2 كامل */
    var arabicLayout: Int
        get() = sp.getInt("arabicLayout", 0)
        set(v) = sp.edit().putInt("arabicLayout", v).apply()

    var showHints: Boolean
        get() = sp.getBoolean("showHints", true)
        set(v) = sp.edit().putBoolean("showHints", v).apply()

    var swipeHint: Boolean
        get() = sp.getBoolean("swipeHint", true)
        set(v) = sp.edit().putBoolean("swipeHint", v).apply()

    var keyPreview: Boolean
        get() = sp.getBoolean("keyPreview", true)
        set(v) = sp.edit().putBoolean("keyPreview", v).apply()

    var numberRow: Boolean
        get() = sp.getBoolean("numberRow", false)
        set(v) = sp.edit().putBoolean("numberRow", v).apply()

    var dedicatedSend: Boolean
        get() = sp.getBoolean("dedicatedSend", true)
        set(v) = sp.edit().putBoolean("dedicatedSend", v).apply()

    var enterSends: Boolean
        get() = sp.getBoolean("enterSends", false)
        set(v) = sp.edit().putBoolean("enterSends", v).apply()

    var suggestEnabled: Boolean
        get() = sp.getBoolean("suggestEnabled", true)
        set(v) = sp.edit().putBoolean("suggestEnabled", v).apply()

    var clipboardEnabled: Boolean
        get() = sp.getBoolean("clipboardEnabled", true)
        set(v) = sp.edit().putBoolean("clipboardEnabled", v).apply()

    var haptic: Boolean
        get() = sp.getBoolean("haptic", true)
        set(v) = sp.edit().putBoolean("haptic", v).apply()

    var sound: Boolean
        get() = sp.getBoolean("sound", false)
        set(v) = sp.edit().putBoolean("sound", v).apply()

    var lang: String
        get() = sp.getString("lang", "ar") ?: "ar"
        set(v) = sp.edit().putString("lang", v).apply()

    var userEmail: String
        get() = sp.getString("userEmail", "") ?: ""
        set(v) = sp.edit().putString("userEmail", v).apply()

    var userName: String
        get() = sp.getString("userName", "") ?: ""
        set(v) = sp.edit().putString("userName", v).apply()

    var accountsJson: String
        get() = sp.getString("accountsJson", "[]") ?: "[]"
        set(v) = sp.edit().putString("accountsJson", v).apply()

    var lastBackupTime: Long
        get() = sp.getLong("lastBackupTime", 0L)
        set(v) = sp.edit().putLong("lastBackupTime", v).apply()

    fun clips(): List<String> {
        val raw = sp.getString("clips", null) ?: return emptyList()
        return try {
            val arr = JSONArray(raw)
            (0 until arr.length()).map { arr.getString(it) }
        } catch (e: Exception) {
            emptyList()
        }
    }

    fun saveClips(list: List<String>) {
        val arr = JSONArray()
        list.forEach { arr.put(it) }
        sp.edit().putString("clips", arr.toString()).apply()
    }
}
__ARABIKEY_EOF__

cat <<'__ARABIKEY_EOF__' > app/src/main/java/com/arabikey/keyboard/Layouts.kt
package com.arabikey.keyboard

enum class Page { AR, AR_SHIFT, EN, EN_SHIFT, SYM, SYM2, EMOJI, STICKER, CLIP, SETTINGS }

enum class KType { CHAR, SHIFT, BACK, ENTER, SPACE, SYM, ABC, EMOJI, STICKER, LANG }

data class Key(
    val label: String,
    val type: KType = KType.CHAR,
    val out: String = label,
    val weight: Float = 1f,
    val alts: List<String> = emptyList(),
    val hint: String = "",
)

object Layouts {

    private fun k(ch: String, hint: String = "", alts: List<String> = emptyList(), w: Float = 1f) =
        Key(ch, KType.CHAR, ch, w, alts, hint)

    private fun chars(s: String): List<Key> =
        s.split(" ").filter { it.isNotEmpty() }.map { Key(it) }

    private fun mark(m: String, alts: List<String> = emptyList()) =
        Key("\u25CC$m", KType.CHAR, m, 1f, alts)

    private fun bottom(enter: String, spaceLabel: String, comma: String, commaAlts: List<String>): List<Key> = listOf(
        Key("123", KType.SYM, weight = 1.45f),
        Key("😊", KType.EMOJI, weight = 1.05f),
        Key("🌐", KType.LANG, weight = 1.05f),
        Key(spaceLabel, KType.SPACE, " ", 3.9f),
        k(comma, alts = commaAlts),
        k(".", "؟", listOf(".", "!", "؟", ":", "،", "؛")),
        Key(enter, KType.ENTER, weight = 1.55f, alts = listOf("➤", "↵")),
    )

    private fun symBottom(enter: String, abc: String): List<Key> = listOf(
        Key(abc, KType.ABC, weight = 1.5f),
        Key("😊", KType.EMOJI, weight = 1.05f),
        Key(" ", KType.SPACE, " ", 4.0f),
        k("،", alts = listOf("،", ",", "؛")),
        k(".", alts = listOf(".", "؟", "!", ":")),
        Key(enter, KType.ENTER, weight = 1.55f, alts = listOf("➤", "↵")),
    )

    private val back = Key("⌫", KType.BACK, weight = 1.45f)
    private fun shift(label: String = "⇧", weight: Float = 1.45f) = Key(label, KType.SHIFT, weight = weight)

    private val arDigitsRow = chars("١ ٢ ٣ ٤ ٥ ٦ ٧ ٨ ٩ ٠")
    private val enDigitsRow = chars("1 2 3 4 5 6 7 8 9 0")

    fun rows(page: Page, enter: String, arabicLayout: Int = 0, numberRow: Boolean = false): List<List<Key>> {
        val base: List<List<Key>> = when (page) {
            Page.AR -> when (arabicLayout) {
                1 -> listOf(
                    listOf(
                        k("ص", "ض", listOf("ض", "ص")),
                        k("ق"),
                        k("ف", "ڤ", listOf("ڤ", "ف")),
                        k("ع", "غ", listOf("غ", "ع")),
                        k("ه", "ة", listOf("ة", "هـ", "ه")),
                        k("ح", "خ", listOf("خ", "ح")),
                        k("ج", "چ", listOf("چ", "ج")),
                        k("د", "ذ", listOf("ذ", "د")),
                    ),
                    listOf(
                        k("س", "ش", listOf("ش", "س")),
                        k("ي", "ى", listOf("ى", "ئ", "ي")),
                        k("ب", "پ", listOf("پ", "ب")),
                        k("ل", "لا", listOf("لا", "لأ", "لإ", "لآ")),
                        k("ا", "أ", listOf("أ", "إ", "آ", "ٱ")),
                        k("ت", "ث", listOf("ث", "ة", "ت")),
                        k("ن"),
                        k("م"),
                    ),
                    listOf(shift(weight = 1.35f)) + listOf(
                        k("ك", "گ", listOf("گ", "ك")),
                        k("ط", "ظ", listOf("ظ", "ط")),
                        k("ر", "ز", listOf("ز", "ژ", "ر")),
                        k("و", "ؤ", listOf("ؤ", "و")),
                        k("ء", "ئ", listOf("ئ", "ؤ", "أ", "إ", "آ")),
                    ) + Key("⌫", KType.BACK, weight = 1.35f),
                    bottom(enter, "العربية", "،", listOf("،", "؛", "؟", "!")),
                )

                2 -> listOf(
                    listOf(
                        k("ض"), k("ص"), k("ث"), k("ق"),
                        k("ف", alts = listOf("ڤ", "ف")),
                        k("غ"), k("ع"),
                        k("ه", "ة", listOf("ة", "هـ")),
                        k("خ"), k("ح"),
                        k("ج", alts = listOf("چ", "ج")),
                        k("د", "ذ", listOf("ذ", "د")),
                    ),
                    listOf(
                        k("ش"), k("س"),
                        k("ي", "ى", listOf("ى", "ئ", "ي")),
                        k("ب", alts = listOf("پ", "ب")),
                        k("ل", "لا", listOf("لا", "لأ", "لإ", "لآ")),
                        k("ا", "أ", listOf("أ", "إ", "آ", "ٱ")),
                        k("ت", alts = listOf("ث", "ة")),
                        k("ن"), k("م"),
                        k("ك", alts = listOf("گ", "ك")),
                        k("ط", "ظ", listOf("ظ", "ط")),
                    ),
                    listOf(shift(weight = 1.35f)) + listOf(
                        k("ذ"), k("ر"), k("ى"), k("ة"),
                        k("و", "ؤ", listOf("ؤ", "و")),
                        k("ز", alts = listOf("ژ", "ز")),
                        k("ظ"),
                        k("ء", "ئ", listOf("ئ", "ؤ", "أ", "إ")),
                    ) + Key("⌫", KType.BACK, weight = 1.35f),
                    bottom(enter, "العربية", "،", listOf("،", "؛", "؟", "!")),
                )

                else -> listOf(
                    listOf(
                        k("ض"),
                        k("ص"),
                        k("ق"),
                        k("ف", alts = listOf("ڤ", "ف")),
                        k("غ"),
                        k("ع"),
                        k("ه", "ة", listOf("ة", "هـ", "ه")),
                        k("ح", "خ", listOf("خ", "ح")),
                        k("ج", "چ", listOf("چ", "ج")),
                        k("د", "ذ", listOf("ذ", "د")),
                    ),
                    listOf(
                        k("ش"),
                        k("س"),
                        k("ي", "ى", listOf("ى", "ئ", "ي")),
                        k("ب", alts = listOf("پ", "ب")),
                        k("ل", "لا", listOf("لا", "لأ", "لإ", "لآ")),
                        k("ا", "أ", listOf("أ", "إ", "آ", "ٱ")),
                        k("ت", "ث", listOf("ث", "ة", "ت")),
                        k("ن"),
                        k("م"),
                        k("ك", alts = listOf("گ", "ك")),
                    ),
                    listOf(shift(weight = 1.4f)) + listOf(
                        k("ء", "ئ", listOf("ئ", "ؤ", "أ", "إ", "آ")),
                        k("ر", alts = listOf("ذ", "ر")),
                        k("ط", "ظ", listOf("ظ", "ط")),
                        k("ة", alts = listOf("ت", "ه")),
                        k("و", "ؤ", listOf("ؤ", "و")),
                        k("ز", alts = listOf("ژ", "ز")),
                    ) + Key("⌫", KType.BACK, weight = 1.4f),
                    bottom(enter, "العربية", "،", listOf("،", "؛", "؟", "!")),
                )
            }

            Page.AR_SHIFT -> listOf(
                listOf(
                    mark("\u064E", listOf("\u064E", "\u064B")),
                    mark("\u064B"),
                    mark("\u064F", listOf("\u064F", "\u064C")),
                    mark("\u064C"),
                    mark("\u0650", listOf("\u0650", "\u064D")),
                    mark("\u064D"),
                    mark("\u0651"),
                    mark("\u0652"),
                    mark("\u0670"),
                    k("ـ"),
                ),
                listOf(
                    k("أ"), k("إ"), k("آ"), k("ٱ"),
                    k("ؤ"), k("ئ"), k("ء"),
                    k("لا"), k("لأ"), k("لإ"), k("لآ"),
                ),
                listOf(shift(weight = 1.35f)) +
                    chars("پ چ ژ ڤ گ « » ؟ ؛") +
                    Key("⌫", KType.BACK, weight = 1.35f),
                bottom(enter, "العربية", "،", listOf("،", "؛", "؟", "!")),
            )

            Page.EN -> listOf(
                listOf(
                    k("q", "1", listOf("1", "q")),
                    k("w", "2", listOf("2", "w")),
                    k("e", "3", listOf("3", "é", "è", "ê", "e")),
                    k("r", "4", listOf("4", "r")),
                    k("t", "5", listOf("5", "t")),
                    k("y", "6", listOf("6", "y")),
                    k("u", "7", listOf("7", "ú", "ü", "u")),
                    k("i", "8", listOf("8", "í", "ï", "i")),
                    k("o", "9", listOf("9", "ó", "ö", "o")),
                    k("p", "0", listOf("0", "p")),
                ),
                listOf(
                    k("a", alts = listOf("á", "à", "â", "ä")),
                    k("s", alts = listOf("ß", "ś", "š")),
                    k("d"), k("f"), k("g"), k("h"), k("j"), k("k"), k("l"),
                ),
                listOf(shift()) + listOf(
                    k("z"), k("x"),
                    k("c", alts = listOf("ç", "ć")),
                    k("v"), k("b"),
                    k("n", alts = listOf("ñ")),
                    k("m"),
                ) + back,
                bottom(enter, "English", ",", listOf(",", ";", "?", "!")),
            )

            Page.EN_SHIFT -> listOf(
                listOf(
                    k("Q", "1", listOf("1", "Q")),
                    k("W", "2", listOf("2", "W")),
                    k("E", "3", listOf("3", "E")),
                    k("R", "4", listOf("4", "R")),
                    k("T", "5", listOf("5", "T")),
                    k("Y", "6", listOf("6", "Y")),
                    k("U", "7", listOf("7", "U")),
                    k("I", "8", listOf("8", "I")),
                    k("O", "9", listOf("9", "O")),
                    k("P", "0", listOf("0", "P")),
                ),
                chars("A S D F G H J K L"),
                listOf(shift()) + chars("Z X C V B N M") + back,
                bottom(enter, "English", ",", listOf(",", ";", "?", "!")),
            )

            Page.SYM -> listOf(
                chars("1 2 3 4 5 6 7 8 9 0"),
                chars("@ # $ % & - + ( ) /"),
                listOf(shift("=\\<")) + chars("* \" ' : ; ! ? ، ؟") + back,
                symBottom(enter, "أبج"),
            )

            Page.SYM2 -> listOf(
                chars("١ ٢ ٣ ٤ ٥ ٦ ٧ ٨ ٩ ٠"),
                chars("﷼ € £ ¥ ٪ ° ± × ÷ ="),
                listOf(shift("123")) + chars("~ ` | ^ < > { } [ ]") + back,
                symBottom(enter, "أبج"),
            )

            else -> emptyList()
        }

        if (!numberRow || base.isEmpty()) return base
        return when (page) {
            Page.AR, Page.AR_SHIFT -> listOf(arDigitsRow) + base
            Page.EN, Page.EN_SHIFT -> listOf(enDigitsRow) + base
            else -> base
        }
    }

    val EMOJIS: List<String> = (
        "😀 😃 😄 😁 😆 😅 😂 🤣 😊 😇 🙂 🙃 😉 😌 😍 🥰 😘 😗 😋 😛 😜 🤪 😎 🤩 🥳 😏 😒 😞 😔 😟 😕 🙁 " +
            "😣 😖 😫 😩 🥺 😢 😭 😤 😠 😡 🤬 🤯 😳 🥵 🥶 😱 😨 😰 😥 😓 🤗 🤔 🤭 🤫 🤥 😶 😐 😑 😬 🙄 😯 " +
            "😴 🤤 😪 😵 🤐 🥴 🤢 🤮 🤧 😷 🤒 🤕 😈 💀 👻 👽 🤖 💩 🙈 🙉 🙊 👍 👎 👌 ✌️ 🤞 🤟 🤘 👏 🙌 🙏 " +
            "💪 👋 🤝 ☝️ 👆 👇 👉 👈 ❤️ 🧡 💛 💚 💙 💜 🖤 🤍 💔 💕 💞 💓 💗 💖 💘 💯 🔥 ✨ ⭐ 🌟 🎉 🎊 🎁 " +
            "☕ 🍵 🍽️ 🍕 🍔 🍟 🍰 🎂 🍫 🍎 🍉 🌹 🌸 🌴 ☀️ 🌙 ⚡ ☔ 🌈 🐱 🐶 🐎 🐪 🦅 🚗 ✈️ 🏠 📱 💻 📷 🎧 🎮 ⚽ 🕌 🕋 📿 🤲 ✅ ❌ ⚠️ ❓ ❗"
        ).split(" ").filter { it.isNotEmpty() }
}
__ARABIKEY_EOF__

cat <<'__ARABIKEY_EOF__' > app/src/main/java/com/arabikey/keyboard/Words.kt
package com.arabikey.keyboard

object Words {
    private val ar: List<String> = (
        "السلام عليكم ورحمة الله وبركاته وعليكم مرحبا مرحباً أهلا أهلاً وسهلا هلا والله وغلا كيف حالك " +
            "الحمد لله بخير شكرا شكراً جزيلا يعطيك العافية الله يعافيك إن شاء الله ماشاء الله بإذن الله " +
            "جزاك الله خيرا صباح الخير مساء الخير تصبح على خير مع السلامة في أمان الله نورت المكان أبشر " +
            "من عيوني تم طال عمرك الموعد القهوة قهوة اليوم غدا بكرة الآن لاحقا اتصل رسالة واتساب المنزل " +
            "البيت العمل الاجتماع المدرسة الجامعة المستشفى المطار السيارة الطريق الوقت الساعة الصباح " +
            "المساء الليل النهار الأسبوع الشهر السنة محمد رسول القرآن الكريم رمضان العيد مبارك كل عام " +
            "وأنتم بخير سعيد تهنئة تعازي صحيح خطأ نعم ربما ممكن أكيد طبعا تمام ممتاز رائع جميل حلو " +
            "حزين مشغول متعب جاهز قريب بعيد سريع بطيء كبير صغير جديد قديم ماذا لماذا متى أين هذا هذه " +
            "ذلك التي الذي إلى على في من عن بعد قبل عند حتى لكن اشتقت أحبك الله يسلمك يسلمو الله يحفظك " +
            "أنا أنت أنتم نحن هم إذا إن أن لأجل لأني لأنه لابد"
        ).split(" ").filter { it.isNotEmpty() }.distinct()

    private val en: List<String> = (
        "hello hi hey thanks thank you please welcome sorry good morning evening night how are what " +
            "when where why who the and for with this that have from your will can would could about " +
            "message call today tomorrow tonight okay yes sure great awesome love friend family work " +
            "home meeting see later soon again really maybe because before after"
        ).split(" ").filter { it.isNotEmpty() }.distinct()

    private val next: Map<String, List<String>> = mapOf(
        "السلام" to listOf("عليكم", "عليكم ورحمة الله وبركاته"),
        "وعليكم" to listOf("السلام", "السلام ورحمة الله"),
        "كيف" to listOf("حالك؟", "الحال؟", "أصبحت؟"),
        "إن" to listOf("شاء الله"),
        "ان" to listOf("شاء الله"),
        "ما" to listOf("شاء الله"),
        "جزاك" to listOf("الله خيرا"),
        "يعطيك" to listOf("العافية"),
        "صباح" to listOf("الخير", "النور"),
        "مساء" to listOf("الخير", "النور"),
        "شكرا" to listOf("لك", "جزيلا", "لك أخي"),
        "شكراً" to listOf("لك", "جزيلا", "لك أخي"),
        "مع" to listOf("السلامة"),
        "الحمد" to listOf("لله"),
        "how" to listOf("are", "is", "do"),
        "thank" to listOf("you"),
        "good" to listOf("morning", "night", "evening"),
    )

    private val defaultsAr = listOf("السلام عليكم", "شكراً", "إن شاء الله")
    private val defaultsEn = listOf("I", "The", "Thanks")

    private fun pad(list: List<String>): List<String> = (list + listOf("", "", "")).take(3)

    private fun norm(s: String): String = buildString {
        for (ch in s) {
            when (ch) {
                'أ', 'إ', 'آ', 'ٱ' -> append('ا')
                'ى' -> append('ي')
                else -> if (Character.getType(ch) != Character.NON_SPACING_MARK.toInt()) append(ch)
            }
        }
    }.lowercase()

    fun suggest(word: String, prev: String, arabic: Boolean): List<String> {
        if (word.isEmpty()) {
            val n = next[prev] ?: next[prev.lowercase()]
            return pad(n ?: if (arabic) defaultsAr else defaultsEn)
        }
        val w = norm(word)
        val pool = if (arabic) ar + en else en + ar
        val matches = pool
            .filter { norm(it).startsWith(w) && norm(it) != w }
            .sortedBy { it.length }
            .take(3)
        if (matches.isEmpty()) return listOf("", word, "")
        return pad(matches)
    }
}
__ARABIKEY_EOF__

cat <<'__ARABIKEY_EOF__' > app/src/main/java/com/arabikey/keyboard/StickerManager.kt
package com.arabikey.keyboard

import android.content.ClipDescription
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Matrix
import android.graphics.Paint
import android.media.ExifInterface
import android.net.Uri
import android.os.Build
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileOutputStream
import kotlin.math.max
import kotlin.math.min

object StickerManager {

    private const val STICKER_SIZE = 512
    private const val MAX_BYTES = 95 * 1024

    fun stickersDir(context: Context): File {
        val dir = File(context.filesDir, "stickers")
        if (!dir.exists()) dir.mkdirs()
        return dir
    }

    fun listStickers(context: Context): List<File> {
        val dir = stickersDir(context)
        return (dir.listFiles() ?: emptyArray())
            .filter { it.isFile && it.name.endsWith(".webp", ignoreCase = true) }
            .sortedByDescending { it.lastModified() }
    }

    fun deleteSticker(file: File): Boolean = try {
        file.delete()
    } catch (e: Exception) {
        false
    }

    fun importFromUri(context: Context, uri: Uri): File? {
        return try {
            val orientation = readExifOrientation(context, uri)
            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            context.contentResolver.openInputStream(uri)?.use {
                BitmapFactory.decodeStream(it, null, bounds)
            }
            if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return null

            var sample = 1
            while ((bounds.outWidth / sample) > STICKER_SIZE * 2 || (bounds.outHeight / sample) > STICKER_SIZE * 2) {
                sample *= 2
            }

            val opts = BitmapFactory.Options().apply { inSampleSize = sample }
            var decoded = context.contentResolver.openInputStream(uri)?.use {
                BitmapFactory.decodeStream(it, null, opts)
            } ?: return null

            if (orientation != 0) {
                val matrix = Matrix().apply { postRotate(orientation.toFloat()) }
                val rotated = Bitmap.createBitmap(decoded, 0, 0, decoded.width, decoded.height, matrix, true)
                if (rotated != decoded) decoded.recycle()
                decoded = rotated
            }

            val canvasBitmap = Bitmap.createBitmap(STICKER_SIZE, STICKER_SIZE, Bitmap.Config.ARGB_8888)
            val canvas = Canvas(canvasBitmap)
            val scale = min(
                STICKER_SIZE.toFloat() / max(1, decoded.width),
                STICKER_SIZE.toFloat() / max(1, decoded.height),
            )
            val targetW = decoded.width * scale
            val targetH = decoded.height * scale
            val left = (STICKER_SIZE - targetW) / 2f
            val top = (STICKER_SIZE - targetH) / 2f
            val destMatrix = Matrix().apply {
                postScale(scale, scale)
                postTranslate(left, top)
            }
            canvas.drawBitmap(decoded, destMatrix, Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG))
            decoded.recycle()

            val webpBytes = compressStickerWebp(canvasBitmap)
            canvasBitmap.recycle()

            val outFile = File(stickersDir(context), "stk_${System.currentTimeMillis()}_${(100..999).random()}.webp")
            FileOutputStream(outFile).use { it.write(webpBytes) }
            outFile
        } catch (e: Exception) {
            null
        }
    }

    private fun readExifOrientation(context: Context, uri: Uri): Int {
        return try {
            context.contentResolver.openInputStream(uri)?.use { stream ->
                val exif = ExifInterface(stream)
                when (exif.getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL)) {
                    ExifInterface.ORIENTATION_ROTATE_90 -> 90
                    ExifInterface.ORIENTATION_ROTATE_180 -> 180
                    ExifInterface.ORIENTATION_ROTATE_270 -> 270
                    else -> 0
                }
            } ?: 0
        } catch (e: Exception) {
            0
        }
    }

    @Suppress("DEPRECATION")
    private fun compressStickerWebp(bitmap: Bitmap): ByteArray {
        val format = if (Build.VERSION.SDK_INT >= 30) {
            Bitmap.CompressFormat.WEBP_LOSSY
        } else {
            Bitmap.CompressFormat.WEBP
        }
        val qualities = intArrayOf(90, 80, 68, 55, 42, 30)
        var lastBytes = ByteArray(0)
        for (q in qualities) {
            val baos = ByteArrayOutputStream()
            bitmap.compress(format, q, baos)
            lastBytes = baos.toByteArray()
            if (lastBytes.size <= MAX_BYTES) return lastBytes
        }
        return lastBytes
    }

    fun getSendableFileAndMime(
        context: Context,
        stickerFile: File,
        acceptedMimes: Array<String>,
    ): Pair<File, String>? {
        fun accepts(mime: String): Boolean =
            acceptedMimes.any { ClipDescription.compareMimeTypes(mime, it) }

        return when {
            accepts("image/webp.wasticker") -> stickerFile to "image/webp.wasticker"
            accepts("image/webp") -> stickerFile to "image/webp"
            accepts("image/png") -> convertTemp(context, stickerFile, Bitmap.CompressFormat.PNG, "png") to "image/png"
            accepts("image/jpeg") -> convertTemp(context, stickerFile, Bitmap.CompressFormat.JPEG, "jpg") to "image/jpeg"
            accepts("image/*") -> stickerFile to "image/webp"
            else -> null
        }
    }

    private fun convertTemp(
        context: Context,
        source: File,
        format: Bitmap.CompressFormat,
        ext: String,
    ): File {
        val out = File(context.cacheDir, "sticker_send.$ext")
        val bmp = BitmapFactory.decodeFile(source.absolutePath)
        if (bmp != null) {
            FileOutputStream(out).use { bmp.compress(format, 92, it) }
            bmp.recycle()
        }
        return out
    }
}
__ARABIKEY_EOF__

cat <<'__ARABIKEY_EOF__' > app/src/main/java/com/arabikey/keyboard/StickerPickerActivity.kt
package com.arabikey.keyboard

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.view.Gravity
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast

class StickerPickerActivity : Activity() {

    companion object {
        private const val REQ_PICK = 1042
    }

    private var launchedPicker = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (savedInstanceState == null && !launchedPicker) {
            launchedPicker = true
            openGalleryPicker()
        }
    }

    private fun openGalleryPicker() {
        val intent = if (Build.VERSION.SDK_INT >= 33) {
            Intent(MediaStore.ACTION_PICK_IMAGES).apply {
                type = "image/*"
                putExtra(MediaStore.EXTRA_PICK_IMAGES_MAX, 10)
            }
        } else {
            Intent(Intent.ACTION_GET_CONTENT).apply {
                type = "image/*"
                putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)
                addCategory(Intent.CATEGORY_OPENABLE)
            }
        }
        try {
            startActivityForResult(Intent.createChooser(intent, "اختر صوراً من الاستديو للملصقات"), REQ_PICK)
        } catch (e: Exception) {
            Toast.makeText(this, "تعذر فتح الاستديو", Toast.LENGTH_SHORT).show()
            finish()
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != REQ_PICK || resultCode != RESULT_OK || data == null) {
            finish()
            return
        }

        val uris = ArrayList<Uri>()
        val clip = data.clipData
        if (clip != null) {
            for (i in 0 until clip.itemCount) {
                clip.getItemAt(i).uri?.let { uris.add(it) }
            }
        } else {
            data.data?.let { uris.add(it) }
        }

        if (uris.isEmpty()) {
            finish()
            return
        }

        showLoadingUi()
        Thread {
            var count = 0
            for (uri in uris) {
                if (StickerManager.importFromUri(this, uri) != null) {
                    count++
                }
            }
            runOnUiThread {
                val msg = if (count > 0) {
                    "تمت إضافة $count ملصق من الاستديو"
                } else {
                    "تعذر استيراد الصورة"
                }
                Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
                finish()
            }
        }.start()
    }

    private fun showLoadingUi() {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(48, 48, 48, 48)
        }
        box.addView(ProgressBar(this))
        val tv = TextView(this).apply {
            text = "جاري تجهيز الملصقات..."
            gravity = Gravity.CENTER
            setPadding(0, 24, 0, 0)
        }
        box.addView(tv)
        setContentView(box)
    }
}
__ARABIKEY_EOF__

cat <<'__ARABIKEY_EOF__' > app/src/main/java/com/arabikey/keyboard/AccountManager.kt
package com.arabikey.keyboard

import android.util.Base64
import android.util.Patterns
import org.json.JSONArray
import org.json.JSONObject
import java.security.MessageDigest
import java.security.SecureRandom

object AccountManager {

    data class Account(
        val email: String,
        val name: String,
        val salt: String,
        val passwordHash: String,
    )

    fun isLoggedIn(prefs: Prefs): Boolean = prefs.userEmail.isNotBlank()

    fun currentAccount(prefs: Prefs): Account? {
        val email = prefs.userEmail.trim().lowercase()
        if (email.isEmpty()) return null
        val list = loadAccounts(prefs)
        return list.firstOrNull { it.email.equals(email, ignoreCase = true) }
            ?: Account(email, prefs.userName.ifBlank { email.substringBefore("@") }, "", "")
    }

    fun register(prefs: Prefs, emailRaw: String, nameRaw: String, password: String): Result<Account> {
        val email = emailRaw.trim().lowercase()
        val name = nameRaw.trim().ifBlank { email.substringBefore("@") }
        if (!Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
            return Result.failure(IllegalArgumentException("يرجى إدخال بريد إلكتروني صحيح"))
        }
        if (password.length < 4) {
            return Result.failure(IllegalArgumentException("كلمة المرور يجب أن تكون ٤ أحرف أو أكثر"))
        }
        val list = loadAccounts(prefs).toMutableList()
        if (list.any { it.email.equals(email, ignoreCase = true) }) {
            return Result.failure(IllegalArgumentException("هذا البريد مسجّل مسبقاً، استخدم تسجيل الدخول"))
        }
        val salt = generateSalt()
        val hash = hashPassword(password, salt)
        val acc = Account(email, name, salt, hash)
        list.add(acc)
        saveAccounts(prefs, list)
        prefs.userEmail = acc.email
        prefs.userName = acc.name
        return Result.success(acc)
    }

    fun login(prefs: Prefs, emailRaw: String, password: String): Result<Account> {
        val email = emailRaw.trim().lowercase()
        if (!Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
            return Result.failure(IllegalArgumentException("البريد الإلكتروني غير صحيح"))
        }
        val list = loadAccounts(prefs)
        val acc = list.firstOrNull { it.email.equals(email, ignoreCase = true) }
            ?: return Result.failure(IllegalArgumentException("لا يوجد حساب مسجّل بهذا البريد على الجهاز"))
        if (acc.passwordHash != hashPassword(password, acc.salt)) {
            return Result.failure(IllegalArgumentException("كلمة المرور غير صحيحة"))
        }
        prefs.userEmail = acc.email
        prefs.userName = acc.name
        return Result.success(acc)
    }

    fun changePassword(prefs: Prefs, oldPass: String, newPass: String): Result<Unit> {
        val cur = currentAccount(prefs)
            ?: return Result.failure(IllegalStateException("لا يوجد حساب مسجّل"))
        if (cur.salt.isNotEmpty() && cur.passwordHash != hashPassword(oldPass, cur.salt)) {
            return Result.failure(IllegalArgumentException("كلمة المرور الحالية غير صحيحة"))
        }
        if (newPass.length < 4) {
            return Result.failure(IllegalArgumentException("كلمة المرور الجديدة قصيرة جداً"))
        }
        val newSalt = generateSalt()
        val newHash = hashPassword(newPass, newSalt)
        val list = loadAccounts(prefs).filterNot { it.email.equals(cur.email, ignoreCase = true) }.toMutableList()
        list.add(Account(cur.email, cur.name, newSalt, newHash))
        saveAccounts(prefs, list)
        return Result.success(Unit)
    }

    fun logout(prefs: Prefs) {
        prefs.userEmail = ""
        prefs.userName = ""
    }

    fun restoreAccountFromBackup(prefs: Prefs, email: String, name: String, salt: String, hash: String) {
        val cleanEmail = email.trim().lowercase()
        if (cleanEmail.isEmpty()) return
        val list = loadAccounts(prefs).filterNot { it.email.equals(cleanEmail, ignoreCase = true) }.toMutableList()
        if (salt.isNotEmpty() && hash.isNotEmpty()) {
            list.add(Account(cleanEmail, name.ifBlank { cleanEmail.substringBefore("@") }, salt, hash))
            saveAccounts(prefs, list)
        }
        prefs.userEmail = cleanEmail
        prefs.userName = name.ifBlank { cleanEmail.substringBefore("@") }
    }

    private fun loadAccounts(prefs: Prefs): List<Account> {
        return try {
            val arr = JSONArray(prefs.accountsJson)
            (0 until arr.length()).map { idx ->
                val o = arr.getJSONObject(idx)
                Account(
                    email = o.optString("email"),
                    name = o.optString("name"),
                    salt = o.optString("salt"),
                    passwordHash = o.optString("hash"),
                )
            }
        } catch (e: Exception) {
            emptyList()
        }
    }

    private fun saveAccounts(prefs: Prefs, list: List<Account>) {
        val arr = JSONArray()
        for (a in list) {
            arr.put(
                JSONObject().apply {
                    put("email", a.email)
                    put("name", a.name)
                    put("salt", a.salt)
                    put("hash", a.passwordHash)
                },
            )
        }
        prefs.accountsJson = arr.toString()
    }

    private fun generateSalt(): String {
        val bytes = ByteArray(16)
        SecureRandom().nextBytes(bytes)
        return Base64.encodeToString(bytes, Base64.NO_WRAP)
    }

    private fun hashPassword(password: String, salt: String): String {
        val md = MessageDigest.getInstance("SHA-256")
        md.update(salt.toByteArray(Charsets.UTF_8))
        val digest = md.digest(password.toByteArray(Charsets.UTF_8))
        return Base64.encodeToString(digest, Base64.NO_WRAP)
    }
}
__ARABIKEY_EOF__

cat <<'__ARABIKEY_EOF__' > app/src/main/java/com/arabikey/keyboard/BackupManager.kt
package com.arabikey.keyboard

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileOutputStream
import java.io.InputStream
import java.io.OutputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream

object BackupManager {

    data class RestoreResult(
        val stickerCount: Int,
        val clipCount: Int,
        val email: String,
    )

    private fun backupsDir(context: Context): File {
        val d = File(context.filesDir, "backups")
        if (!d.exists()) d.mkdirs()
        return d
    }

    fun localSnapshotFile(context: Context): File = File(backupsDir(context), "latest_local_backup.zip")

    fun hasLocalSnapshot(context: Context): Boolean = localSnapshotFile(context).exists()

    fun saveLocalSnapshot(context: Context): File? {
        val f = localSnapshotFile(context)
        return try {
            FileOutputStream(f).use { out ->
                if (createBackupZip(context, out)) f else null
            }
        } catch (e: Exception) {
            null
        }
    }

    fun prepareEmailBackupFile(context: Context): File? {
        val f = File(backupsDir(context), "ArabiKey_Backup.zip")
        return try {
            FileOutputStream(f).use { out ->
                if (createBackupZip(context, out)) f else null
            }
        } catch (e: Exception) {
            null
        }
    }

    fun createBackupZip(context: Context, out: OutputStream): Boolean {
        return try {
            val prefs = Prefs(context)
            val acc = AccountManager.currentAccount(prefs)
            val stickers = StickerManager.listStickers(context)

            val settingsObj = JSONObject().apply {
                put("theme", prefs.theme)
                put("keyHeight", prefs.keyHeight)
                put("fontSize", prefs.fontSize)
                put("arabicLayout", prefs.arabicLayout)
                put("showHints", prefs.showHints)
                put("swipeHint", prefs.swipeHint)
                put("keyPreview", prefs.keyPreview)
                put("numberRow", prefs.numberRow)
                put("dedicatedSend", prefs.dedicatedSend)
                put("enterSends", prefs.enterSends)
                put("suggestEnabled", prefs.suggestEnabled)
                put("clipboardEnabled", prefs.clipboardEnabled)
                put("haptic", prefs.haptic)
                put("sound", prefs.sound)
                put("lang", prefs.lang)
            }

            val clipsArr = JSONArray().apply {
                prefs.clips().forEach { put(it) }
            }

            val manifest = JSONObject().apply {
                put("formatVersion", 1)
                put("createdAt", System.currentTimeMillis())
                put("email", acc?.email ?: "")
                put("name", acc?.name ?: "")
                put("salt", acc?.salt ?: "")
                put("passwordHash", acc?.passwordHash ?: "")
                put("settings", settingsObj)
                put("clips", clipsArr)
                put("stickerCount", stickers.size)
            }

            ZipOutputStream(out).use { zos ->
                zos.putNextEntry(ZipEntry("manifest.json"))
                zos.write(manifest.toString(2).toByteArray(Charsets.UTF_8))
                zos.closeEntry()

                for (stk in stickers) {
                    zos.putNextEntry(ZipEntry("stickers/${stk.name}"))
                    stk.inputStream().use { it.copyTo(zos) }
                    zos.closeEntry()
                }
            }
            prefs.lastBackupTime = System.currentTimeMillis()
            true
        } catch (e: Exception) {
            false
        }
    }

    fun restoreFromStream(context: Context, input: InputStream): Result<RestoreResult> {
        return try {
            var manifestStr: String? = null
            val restoredStickers = ArrayList<Pair<String, ByteArray>>()

            ZipInputStream(input).use { zis ->
                var entry = zis.nextEntry
                while (entry != null) {
                    val name = entry.name
                    if (!entry.isDirectory && !name.contains("..")) {
                        if (name == "manifest.json") {
                            manifestStr = readBytes(zis).toString(Charsets.UTF_8)
                        } else if (name.startsWith("stickers/") && name.endsWith(".webp", ignoreCase = true)) {
                            val safeName = File(name).name
                            if (safeName.isNotBlank()) {
                                restoredStickers.add(safeName to readBytes(zis))
                            }
                        }
                    }
                    zis.closeEntry()
                    entry = zis.nextEntry
                }
            }

            val rawManifest = manifestStr
                ?: return Result.failure(IllegalArgumentException("ملف النسخة الاحتياطية غير صالح"))

            val manifest = JSONObject(rawManifest)
            val prefs = Prefs(context)

            manifest.optJSONObject("settings")?.let { s ->
                if (s.has("theme")) prefs.theme = s.optString("theme", "snow")
                if (s.has("keyHeight")) prefs.keyHeight = s.optInt("keyHeight", 2)
                if (s.has("fontSize")) prefs.fontSize = s.optInt("fontSize", 1)
                if (s.has("arabicLayout")) prefs.arabicLayout = s.optInt("arabicLayout", 0)
                if (s.has("showHints")) prefs.showHints = s.optBoolean("showHints", true)
                if (s.has("swipeHint")) prefs.swipeHint = s.optBoolean("swipeHint", true)
                if (s.has("keyPreview")) prefs.keyPreview = s.optBoolean("keyPreview", true)
                if (s.has("numberRow")) prefs.numberRow = s.optBoolean("numberRow", false)
                if (s.has("dedicatedSend")) prefs.dedicatedSend = s.optBoolean("dedicatedSend", true)
                if (s.has("enterSends")) prefs.enterSends = s.optBoolean("enterSends", false)
                if (s.has("suggestEnabled")) prefs.suggestEnabled = s.optBoolean("suggestEnabled", true)
                if (s.has("clipboardEnabled")) prefs.clipboardEnabled = s.optBoolean("clipboardEnabled", true)
                if (s.has("haptic")) prefs.haptic = s.optBoolean("haptic", true)
                if (s.has("sound")) prefs.sound = s.optBoolean("sound", false)
                if (s.has("lang")) prefs.lang = s.optString("lang", "ar")
            }

            var clipCount = 0
            manifest.optJSONArray("clips")?.let { arr ->
                val list = (0 until arr.length()).map { arr.getString(it) }
                prefs.saveClips(list)
                clipCount = list.size
            }

            val stickersDir = StickerManager.stickersDir(context)
            for ((fileName, bytes) in restoredStickers) {
                val outFile = File(stickersDir, fileName)
                FileOutputStream(outFile).use { it.write(bytes) }
            }

            val email = manifest.optString("email", "")
            val name = manifest.optString("name", "")
            val salt = manifest.optString("salt", "")
            val hash = manifest.optString("passwordHash", "")
            if (email.isNotBlank()) {
                AccountManager.restoreAccountFromBackup(prefs, email, name, salt, hash)
            }

            Result.success(RestoreResult(restoredStickers.size, clipCount, email))
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    private fun readBytes(zis: ZipInputStream): ByteArray {
        val baos = ByteArrayOutputStream()
        val buf = ByteArray(4096)
        var n: Int
        while (zis.read(buf).also { n = it } != -1) {
            baos.write(buf, 0, n)
        }
        return baos.toByteArray()
    }
}
__ARABIKEY_EOF__

cat <<'__ARABIKEY_EOF__' > app/src/main/java/com/arabikey/keyboard/ArabiKeyService.kt
package com.arabikey.keyboard

import android.content.ClipDescription
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.res.Configuration
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.StateListDrawable
import android.inputmethodservice.InputMethodService
import android.media.AudioManager
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.text.InputType
import android.text.TextUtils
import android.util.TypedValue
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.PopupWindow
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.core.content.FileProvider
import androidx.core.view.inputmethod.EditorInfoCompat
import androidx.core.view.inputmethod.InputConnectionCompat
import androidx.core.view.inputmethod.InputContentInfoCompat
import java.io.File
import kotlin.math.abs

class ArabiKeyService : InputMethodService() {

    private val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
    private val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT

    private lateinit var prefs: Prefs
    private var kb: KbTheme = KbTheme.SNOW
    private var root: LinearLayout? = null
    private var keysHost: LinearLayout? = null

    private var page = Page.AR
    private var lang = "ar"
    private var shiftState = 0
    private var haptic = true
    private var sound = false
    private var suggestOn = true
    private var selectedSticker: File? = null

    private var suggestionViews: List<TextView> = emptyList()
    private var suggestions: List<String> = listOf("", "", "")

    private val handler = Handler(Looper.getMainLooper())
    private var clipListener: ClipboardManager.OnPrimaryClipChangedListener? = null

    private var popup: PopupWindow? = null
    private var popupRow: LinearLayout? = null
    private var popupAlts: List<String> = emptyList()
    private var popupSelectedIdx = 0
    private var popupOriginX = 0
    private var popupItemW = 0

    private val repeatBack = object : Runnable {
        override fun run() {
            backspace()
            handler.postDelayed(this, 45)
        }
    }

    override fun onCreate() {
        super.onCreate()
        prefs = Prefs(this)
        kb = KbTheme.byName(prefs.theme)
        lang = prefs.lang
        try {
            val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            val l = ClipboardManager.OnPrimaryClipChangedListener {
                if (prefs.clipboardEnabled) captureClip(cm)
            }
            clipListener = l
            cm.addPrimaryClipChangedListener(l)
        } catch (e: Exception) {
        }
    }

    override fun onDestroy() {
        dismissPopup()
        handler.removeCallbacksAndMessages(null)
        try {
            val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            clipListener?.let { cm.removePrimaryClipChangedListener(it) }
        } catch (e: Exception) {
        }
        super.onDestroy()
    }

    override fun onEvaluateFullscreenMode(): Boolean = false

    override fun onCreateInputView(): View {